import { NextRequest, NextResponse } from 'next/server';
import { getStateElectricityData, getRenewableGenerationData } from '@/lib/eia-api';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const statesParam = searchParams.get('states');
    const years = parseInt(searchParams.get('years') || '3');
    const includeRenewable = searchParams.get('renewable') === 'true';

    // Parse states parameter
    let states: string[] = ['CA', 'TX', 'FL', 'NY', 'NC']; // Default states
    if (statesParam) {
      states = statesParam.split(',').map(s => s.trim().toUpperCase());
    }

    // Get electricity sales data
    const electricityData = await getStateElectricityData(states, years);

    let renewableData = [];
    if (includeRenewable) {
      // Get renewable generation data for each state
      for (const state of states) {
        const stateRenewableData = await getRenewableGenerationData(state);
        renewableData.push(...stateRenewableData);
      }
    }

    // Process and aggregate data by state
    const stateStats = states.map(state => {
      const stateElectricity = electricityData.filter(d => d.stateid === state);
      const stateRenewable = renewableData.filter(d => d.location === state);

      const totalSales = stateElectricity.reduce((sum, d) => sum + d.sales, 0);
      const avgSales = totalSales / Math.max(stateElectricity.length, 1);

      return {
        state,
        stateDescription: stateElectricity[0]?.stateDescription || state,
        totalSales,
        avgSales,
        dataPoints: stateElectricity.length,
        renewableDataPoints: stateRenewable.length,
        latestPeriod: stateElectricity[0]?.period || null
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        states: stateStats,
        electricityData,
        renewableData: includeRenewable ? renewableData : null
      },
      metadata: {
        states: states,
        years,
        includeRenewable,
        totalDataPoints: electricityData.length
      }
    });

  } catch (error) {
    console.error('EIA States API Error:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch state electricity data',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      states = ['CA', 'TX', 'FL', 'NY'], 
      years = 3,
      includeRenewable = false,
      customDateRange 
    } = body;

    if (!Array.isArray(states)) {
      return NextResponse.json({
        success: false,
        error: 'Invalid request',
        message: 'States must be an array'
      }, { status: 400 });
    }

    // Get electricity data
    const electricityData = await getStateElectricityData(states, years);

    // Get renewable data if requested
    let renewableData = [];
    if (includeRenewable) {
      for (const state of states) {
        const stateRenewableData = await getRenewableGenerationData(state);
        renewableData.push(...stateRenewableData);
      }
    }

    // Calculate trends and insights
    const insights = {
      topStates: electricityData
        .reduce((acc, curr) => {
          const existing = acc.find(item => item.state === curr.stateid);
          if (existing) {
            existing.totalSales += curr.sales;
          } else {
            acc.push({
              state: curr.stateid,
              stateDescription: curr.stateDescription,
              totalSales: curr.sales
            });
          }
          return acc;
        }, [] as any[])
        .sort((a, b) => b.totalSales - a.totalSales)
        .slice(0, 5),
      
      totalNationalSales: electricityData.reduce((sum, d) => sum + d.sales, 0),
      averageSalesByState: electricityData.reduce((sum, d) => sum + d.sales, 0) / states.length
    };

    return NextResponse.json({
      success: true,
      data: {
        electricityData,
        renewableData: includeRenewable ? renewableData : null,
        insights
      },
      metadata: {
        states,
        years,
        includeRenewable,
        customDateRange,
        totalDataPoints: electricityData.length
      }
    });

  } catch (error) {
    console.error('EIA States POST API Error:', error);
    
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch state electricity data',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}

