import { Metadata } from "next";
import Hero from "@/components/Home/Hero";
import Services from "@/components/Home/Services";
import EIAIntegration from "@/components/Home/EIAIntegration";
import SolarProjectsMap from "@/components/Home/SolarProjectsMap";

export const metadata: Metadata = {
  title: "Compliance Drone - Energy Infrastructure Management",
  description: "Professional inspection and oversight services for energy infrastructure. Automated EIA compliance monitoring and solar project management.",
  keywords: "drone inspection, energy infrastructure, solar compliance, EIA monitoring, regulatory oversight",
};

export default function Home() {
  return (
    <>
      <Hero />
      <Services />
      <EIAIntegration />
      <SolarProjectsMap />
    </>
  );
}
