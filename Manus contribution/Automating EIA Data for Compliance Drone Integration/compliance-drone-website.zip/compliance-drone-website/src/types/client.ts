export type Client = {
  id: number;
  image: string;
  title?: string;
  description?: string;
};
