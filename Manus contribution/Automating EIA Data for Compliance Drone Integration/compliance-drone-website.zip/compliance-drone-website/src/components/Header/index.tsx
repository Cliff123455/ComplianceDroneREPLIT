"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";

const Header = () => {
  const [navigationOpen, setNavigationOpen] = useState(false);
  const pathname = usePathname();

  const navigationItems = [
    {
      title: "Home",
      path: "/",
    },
    {
      title: "Dashboard",
      path: "/dashboard",
    },
    {
      title: "Services",
      path: "/services",
    },
    {
      title: "Contact",
      path: "/contact",
    },
  ];

  return (
    <header className="relative z-50 bg-white shadow-lg dark:bg-dark">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <Image
                src="/images/BannerLOGO.png"
                alt="Compliance Drone"
                width={200}
                height={60}
                className="h-12 w-auto"
              />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex md:items-center md:space-x-8">
            {navigationItems.map((item) => (
              <Link
                key={item.title}
                href={item.path}
                className={`text-sm font-medium transition-colors hover:text-orange-600 ${
                  pathname === item.path
                    ? "text-orange-600"
                    : "text-gray-700 dark:text-gray-300"
                }`}
              >
                {item.title}
              </Link>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex md:items-center">
            <Link
              href="/dashboard"
              className="rounded-lg bg-gradient-to-r from-blue-600 to-orange-600 px-6 py-2 text-sm font-medium text-white transition-all duration-300 hover:from-blue-700 hover:to-orange-700 hover:shadow-lg"
            >
              View Dashboard
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setNavigationOpen(!navigationOpen)}
              className="inline-flex items-center justify-center rounded-md p-2 text-gray-700 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white"
            >
              <span className="sr-only">Open main menu</span>
              {navigationOpen ? (
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M6 18L18 6M6 6l12 12"
                  />
                </svg>
              ) : (
                <svg
                  className="h-6 w-6"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 6h16M4 12h16M4 18h16"
                  />
                </svg>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {navigationOpen && (
          <div className="md:hidden">
            <div className="space-y-1 px-2 pb-3 pt-2">
              {navigationItems.map((item) => (
                <Link
                  key={item.title}
                  href={item.path}
                  className={`block rounded-md px-3 py-2 text-base font-medium transition-colors ${
                    pathname === item.path
                      ? "bg-orange-100 text-orange-600 dark:bg-orange-900/20 dark:text-orange-400"
                      : "text-gray-700 hover:bg-gray-100 hover:text-gray-900 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white"
                  }`}
                  onClick={() => setNavigationOpen(false)}
                >
                  {item.title}
                </Link>
              ))}
              <Link
                href="/dashboard"
                className="block rounded-md bg-gradient-to-r from-blue-600 to-orange-600 px-3 py-2 text-base font-medium text-white"
                onClick={() => setNavigationOpen(false)}
              >
                View Dashboard
              </Link>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;
