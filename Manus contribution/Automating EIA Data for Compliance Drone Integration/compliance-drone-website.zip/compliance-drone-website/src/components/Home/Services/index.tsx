import Image from "next/image";
import Link from "next/link";

const servicesData = [
  {
    id: 1,
    icon: "/images/services/drone-inspection.svg",
    title: "Drone Inspection Services",
    description: "Professional aerial inspections of solar installations, wind farms, and energy infrastructure using advanced drone technology.",
    features: ["High-resolution imaging", "Thermal analysis", "3D mapping", "Real-time reporting"],
    link: "/services/inspection"
  },
  {
    id: 2,
    icon: "/images/services/eia-monitoring.svg", 
    title: "EIA Compliance Monitoring",
    description: "Automated monitoring and reporting of Energy Information Administration compliance requirements for energy projects.",
    features: ["Real-time data sync", "Automated reporting", "Compliance alerts", "Regulatory updates"],
    link: "/services/compliance"
  },
  {
    id: 3,
    icon: "/images/services/project-management.svg",
    title: "Project Management",
    description: "Comprehensive project tracking and management tools for renewable energy installations and infrastructure projects.",
    features: ["Project tracking", "Document management", "Progress monitoring", "Team collaboration"],
    link: "/services/management"
  }
];

const Services = () => {
  return (
    <section className="relative z-10 overflow-hidden bg-gray-1 py-20 dark:bg-dark-2 lg:py-25">
      <div className="mx-auto max-w-7xl px-4 sm:px-8 xl:px-0">
        {/* Section Header */}
        <div className="mx-auto mb-12.5 max-w-[690px] text-center">
          <span className="mb-4 inline-block rounded-full bg-gradient-to-r from-blue-500 to-orange-500 px-4.5 py-2 text-sm font-medium text-white">
            Our Services
          </span>
          <h2 className="mb-5 text-3xl font-bold text-black dark:text-white sm:text-4xl xl:text-heading-2">
            Comprehensive Energy Infrastructure Solutions
          </h2>
          <p className="font-medium text-body-color dark:text-body-color-dark">
            From drone inspections to regulatory compliance, we provide end-to-end services 
            for the renewable energy sector.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {servicesData.map((service) => (
            <div
              key={service.id}
              className="group relative overflow-hidden rounded-lg bg-white p-8 shadow-lg transition-all duration-300 hover:shadow-xl dark:bg-dark"
            >
              {/* Service Icon */}
              <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-lg bg-gradient-to-r from-blue-500 to-orange-500">
                <div className="h-8 w-8 rounded bg-white/20"></div>
              </div>

              {/* Service Content */}
              <h3 className="mb-4 text-xl font-bold text-black dark:text-white">
                {service.title}
              </h3>
              
              <p className="mb-6 text-body-color dark:text-body-color-dark">
                {service.description}
              </p>

              {/* Features List */}
              <ul className="mb-6 space-y-2">
                {service.features.map((feature, index) => (
                  <li key={index} className="flex items-center text-sm text-body-color dark:text-body-color-dark">
                    <div className="mr-2 h-2 w-2 rounded-full bg-gradient-to-r from-blue-500 to-orange-500"></div>
                    {feature}
                  </li>
                ))}
              </ul>

              {/* Learn More Link */}
              <Link
                href={service.link}
                className="inline-flex items-center font-medium text-blue-600 transition-colors hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300"
              >
                Learn More
                <svg
                  className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </Link>

              {/* Hover Effect */}
              <div className="absolute inset-0 -z-1 bg-gradient-to-r from-blue-500/5 to-orange-500/5 opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-12.5 text-center">
          <p className="mb-6 text-lg font-medium text-body-color dark:text-body-color-dark">
            Ready to streamline your energy infrastructure management?
          </p>
          <Link
            href="/auth/signup"
            className="inline-flex rounded-lg bg-gradient-to-r from-blue-600 to-orange-600 px-8 py-3 font-medium text-white transition-all duration-300 hover:from-blue-700 hover:to-orange-700 hover:shadow-lg"
          >
            Get Started Today
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Services;

