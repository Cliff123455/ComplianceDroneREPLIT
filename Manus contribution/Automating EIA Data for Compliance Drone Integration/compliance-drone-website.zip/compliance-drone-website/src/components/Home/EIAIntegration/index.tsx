"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

interface EIAStats {
  totalPlants: number;
  solarPlants: number;
  totalCapacity: string;
  topStates: Array<{ state: string; count: number }>;
}

const EIAIntegration = () => {
  const [stats, setStats] = useState<EIAStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API call to get EIA stats
    const fetchStats = async () => {
      try {
        // In a real implementation, this would call the EIA API
        await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate loading
        
        setStats({
          totalPlants: 12709,
          solarPlants: 6698,
          totalCapacity: "113.1 GW",
          topStates: [
            { state: "CA", count: 997 },
            { state: "NC", count: 790 },
            { state: "MN", count: 687 },
            { state: "NY", count: 536 },
            { state: "MA", count: 520 }
          ]
        });
      } catch (error) {
        console.error("Failed to fetch EIA stats:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  return (
    <section className="relative z-10 overflow-hidden py-20 lg:py-25">
      <div className="mx-auto max-w-7xl px-4 sm:px-8 xl:px-0">
        {/* Section Header */}
        <div className="mx-auto mb-12.5 max-w-[690px] text-center">
          <span className="mb-4 inline-block rounded-full bg-gradient-to-r from-blue-500 to-orange-500 px-4.5 py-2 text-sm font-medium text-white">
            EIA Integration
          </span>
          <h2 className="mb-5 text-3xl font-bold text-black dark:text-white sm:text-4xl xl:text-heading-2">
            Real-Time Energy Data Automation
          </h2>
          <p className="font-medium text-body-color dark:text-body-color-dark">
            Automated integration with the U.S. Energy Information Administration database 
            for comprehensive energy infrastructure monitoring and compliance tracking.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          {/* Features List */}
          <div className="space-y-8">
            <div className="rounded-lg bg-white p-6 shadow-lg dark:bg-dark">
              <div className="mb-4 flex items-center">
                <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-r from-blue-500 to-orange-500">
                  <div className="h-6 w-6 rounded bg-white/20"></div>
                </div>
                <h3 className="text-xl font-bold text-black dark:text-white">
                  Plant Monitoring
                </h3>
              </div>
              <p className="text-body-color dark:text-body-color-dark">
                Real-time monitoring of solar plants and energy facilities with automated 
                status updates and compliance tracking.
              </p>
            </div>

            <div className="rounded-lg bg-white p-6 shadow-lg dark:bg-dark">
              <div className="mb-4 flex items-center">
                <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-r from-blue-500 to-orange-500">
                  <div className="h-6 w-6 rounded bg-white/20"></div>
                </div>
                <h3 className="text-xl font-bold text-black dark:text-white">
                  Market Intelligence
                </h3>
              </div>
              <p className="text-body-color dark:text-body-color-dark">
                Comprehensive market analysis with state-by-state comparisons, 
                capacity trends, and competitive intelligence.
              </p>
            </div>

            <div className="rounded-lg bg-white p-6 shadow-lg dark:bg-dark">
              <div className="mb-4 flex items-center">
                <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-r from-blue-500 to-orange-500">
                  <div className="h-6 w-6 rounded bg-white/20"></div>
                </div>
                <h3 className="text-xl font-bold text-black dark:text-white">
                  Compliance Automation
                </h3>
              </div>
              <p className="text-body-color dark:text-body-color-dark">
                Automated regulatory compliance monitoring with alerts for 
                reporting deadlines and regulatory changes.
              </p>
            </div>
          </div>

          {/* Live Stats Dashboard */}
          <div className="rounded-lg bg-gradient-to-br from-blue-50 to-orange-50 p-8 dark:from-blue-900/20 dark:to-orange-900/20">
            <h3 className="mb-6 text-2xl font-bold text-black dark:text-white">
              Live EIA Data
            </h3>
            
            {loading ? (
              <div className="space-y-4">
                <div className="h-4 w-3/4 animate-pulse rounded bg-gray-300 dark:bg-gray-600"></div>
                <div className="h-4 w-1/2 animate-pulse rounded bg-gray-300 dark:bg-gray-600"></div>
                <div className="h-4 w-2/3 animate-pulse rounded bg-gray-300 dark:bg-gray-600"></div>
              </div>
            ) : stats ? (
              <div className="space-y-6">
                {/* Key Metrics */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="rounded-lg bg-white/50 p-4 dark:bg-black/20">
                    <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      {stats.totalPlants.toLocaleString()}
                    </div>
                    <div className="text-sm text-body-color dark:text-body-color-dark">
                      Total Power Plants
                    </div>
                  </div>
                  <div className="rounded-lg bg-white/50 p-4 dark:bg-black/20">
                    <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                      {stats.solarPlants.toLocaleString()}
                    </div>
                    <div className="text-sm text-body-color dark:text-body-color-dark">
                      Solar Facilities
                    </div>
                  </div>
                </div>

                {/* Total Capacity */}
                <div className="rounded-lg bg-white/50 p-4 dark:bg-black/20">
                  <div className="text-3xl font-bold text-green-600 dark:text-green-400">
                    {stats.totalCapacity}
                  </div>
                  <div className="text-sm text-body-color dark:text-body-color-dark">
                    Total Solar Capacity
                  </div>
                </div>

                {/* Top States */}
                <div>
                  <h4 className="mb-3 font-semibold text-black dark:text-white">
                    Top Solar States
                  </h4>
                  <div className="space-y-2">
                    {stats.topStates.map((state, index) => (
                      <div key={state.state} className="flex items-center justify-between">
                        <span className="text-body-color dark:text-body-color-dark">
                          {index + 1}. {state.state}
                        </span>
                        <span className="font-medium text-black dark:text-white">
                          {state.count} plants
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center text-body-color dark:text-body-color-dark">
                Failed to load EIA data
              </div>
            )}

            {/* View Dashboard Button */}
            <div className="mt-6">
              <Link
                href="/dashboard"
                className="inline-flex w-full items-center justify-center rounded-lg bg-gradient-to-r from-blue-600 to-orange-600 px-6 py-3 font-medium text-white transition-all duration-300 hover:from-blue-700 hover:to-orange-700 hover:shadow-lg"
              >
                View Full Dashboard
                <svg
                  className="ml-2 h-4 w-4"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default EIAIntegration;

