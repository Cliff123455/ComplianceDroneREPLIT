"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

interface SolarProject {
  id: string;
  name: string;
  state: string;
  latitude: number;
  longitude: number;
  capacity: number;
  status: "operating" | "under-construction" | "planned";
  year: number;
}

const SolarProjectsMap = () => {
  const [projects, setProjects] = useState<SolarProject[]>([]);
  const [selectedState, setSelectedState] = useState<string>("all");
  const [loading, setLoading] = useState(true);

  // Mock data based on the KMZ files analyzed
  const mockProjects: SolarProject[] = [
    {
      id: "1",
      name: "Desert Sunlight Solar Farm",
      state: "CA",
      latitude: 33.7,
      longitude: -115.4,
      capacity: 690,
      status: "operating",
      year: 2015
    },
    {
      id: "2",
      name: "Topaz Solar Farm",
      state: "CA",
      latitude: 35.4,
      longitude: -120.1,
      capacity: 550,
      status: "operating",
      year: 2014
    },
    {
      id: "3",
      name: "Solar Star Projects",
      state: "CA",
      latitude: 34.9,
      longitude: -118.2,
      capacity: 579,
      status: "operating",
      year: 2015
    },
    {
      id: "4",
      name: "Copper Mountain Solar",
      state: "NV",
      latitude: 35.7,
      longitude: -114.9,
      capacity: 458,
      status: "operating",
      year: 2016
    },
    {
      id: "5",
      name: "Agua Caliente Solar",
      state: "AZ",
      latitude: 32.9,
      longitude: -113.3,
      capacity: 397,
      status: "operating",
      year: 2014
    },
    {
      id: "6",
      name: "Future Solar Project Alpha",
      state: "TX",
      latitude: 31.5,
      longitude: -102.1,
      capacity: 800,
      status: "planned",
      year: 2025
    },
    {
      id: "7",
      name: "Future Solar Project Beta",
      state: "AZ",
      latitude: 33.2,
      longitude: -112.8,
      capacity: 650,
      status: "planned",
      year: 2026
    },
    {
      id: "8",
      name: "Nevada Solar Expansion",
      state: "NV",
      latitude: 36.1,
      longitude: -115.2,
      capacity: 720,
      status: "under-construction",
      year: 2024
    }
  ];

  useEffect(() => {
    const fetchProjects = async () => {
      setLoading(true);
      await new Promise(resolve => setTimeout(resolve, 800));
      setProjects(mockProjects);
      setLoading(false);
    };

    fetchProjects();
  }, []);

  const filteredProjects = selectedState === "all" 
    ? projects 
    : projects.filter(project => project.state === selectedState);

  const states = [...new Set(projects.map(p => p.state))].sort();

  const getStatusColor = (status: string) => {
    switch (status) {
      case "operating":
        return "bg-green-500";
      case "under-construction":
        return "bg-yellow-500";
      case "planned":
        return "bg-blue-500";
      default:
        return "bg-gray-500";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "operating":
        return "🟢";
      case "under-construction":
        return "🟡";
      case "planned":
        return "🔵";
      default:
        return "⚪";
    }
  };

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 dark:text-white sm:text-4xl">
            Solar Project Locations
          </h2>
          <p className="mt-4 text-lg text-gray-600 dark:text-gray-300">
            Real-time tracking of solar installations across the United States
          </p>
        </div>

        {/* Filter Controls */}
        <div className="mb-8 flex flex-wrap items-center justify-center gap-4">
          <select
            value={selectedState}
            onChange={(e) => setSelectedState(e.target.value)}
            className="rounded-lg border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:border-orange-500 focus:outline-none focus:ring-2 focus:ring-orange-500 dark:border-gray-600 dark:bg-gray-800 dark:text-gray-300"
          >
            <option value="all">All States ({projects.length} projects)</option>
            {states.map(state => (
              <option key={state} value={state}>
                {state} ({projects.filter(p => p.state === state).length} projects)
              </option>
            ))}
          </select>
        </div>

        {loading ? (
          <div className="space-y-6">
            <div className="h-96 animate-pulse rounded-lg bg-gray-300 dark:bg-gray-700"></div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="h-32 animate-pulse rounded-lg bg-gray-300 dark:bg-gray-700"></div>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-8">
            {/* Map Visualization */}
            <div className="relative overflow-hidden rounded-lg bg-gradient-to-br from-blue-100 to-green-100 dark:from-blue-900/20 dark:to-green-900/20">
              <div className="h-96 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">🗺️</div>
                  <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200 mb-2">
                    Interactive Solar Project Map
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    Showing {filteredProjects.length} solar projects
                  </p>
                  <Link
                    href="/dashboard"
                    className="inline-flex items-center rounded-lg bg-gradient-to-r from-blue-600 to-orange-600 px-6 py-3 text-sm font-medium text-white transition-all duration-300 hover:from-blue-700 hover:to-orange-700 hover:shadow-lg"
                  >
                    View Full Interactive Map
                    <svg className="ml-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </Link>
                </div>
              </div>
              
              {/* Mock location pins */}
              <div className="absolute left-1/4 top-1/3">
                <div className="h-4 w-4 rounded-full bg-green-500 shadow-lg animate-pulse"></div>
              </div>
              <div className="absolute left-2/3 top-1/2">
                <div className="h-4 w-4 rounded-full bg-green-500 shadow-lg animate-pulse"></div>
              </div>
              <div className="absolute right-1/4 bottom-1/3">
                <div className="h-4 w-4 rounded-full bg-blue-500 shadow-lg animate-pulse"></div>
              </div>
              <div className="absolute left-1/2 top-2/3">
                <div className="h-4 w-4 rounded-full bg-yellow-500 shadow-lg animate-pulse"></div>
              </div>
            </div>

            {/* Project Grid */}
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
              {filteredProjects.map((project) => (
                <div
                  key={project.id}
                  className="rounded-lg border border-gray-200 bg-white p-6 shadow-sm transition-shadow hover:shadow-md dark:border-gray-700 dark:bg-gray-800"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <span className="text-lg">{getStatusIcon(project.status)}</span>
                        <h3 className="font-semibold text-gray-900 dark:text-white">
                          {project.name}
                        </h3>
                      </div>
                      <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                        <p><span className="font-medium">State:</span> {project.state}</p>
                        <p><span className="font-medium">Capacity:</span> {project.capacity} MW</p>
                        <p><span className="font-medium">Year:</span> {project.year}</p>
                        <p><span className="font-medium">Location:</span> {project.latitude.toFixed(2)}, {project.longitude.toFixed(2)}</p>
                      </div>
                    </div>
                    <div className={`rounded-full px-2 py-1 text-xs font-medium text-white ${getStatusColor(project.status)}`}>
                      {project.status.replace('-', ' ')}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Summary Stats */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div className="rounded-lg bg-green-50 p-6 text-center dark:bg-green-900/20">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {projects.filter(p => p.status === "operating").length}
                </div>
                <div className="text-sm text-green-700 dark:text-green-300">
                  Operating Projects
                </div>
              </div>
              <div className="rounded-lg bg-yellow-50 p-6 text-center dark:bg-yellow-900/20">
                <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                  {projects.filter(p => p.status === "under-construction").length}
                </div>
                <div className="text-sm text-yellow-700 dark:text-yellow-300">
                  Under Construction
                </div>
              </div>
              <div className="rounded-lg bg-blue-50 p-6 text-center dark:bg-blue-900/20">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {projects.filter(p => p.status === "planned").length}
                </div>
                <div className="text-sm text-blue-700 dark:text-blue-300">
                  Planned Projects
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default SolarProjectsMap;

