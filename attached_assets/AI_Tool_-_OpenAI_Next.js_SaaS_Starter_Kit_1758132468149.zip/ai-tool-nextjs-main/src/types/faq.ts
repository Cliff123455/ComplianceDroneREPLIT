export type FAQ = {
  id: number;
  question: string;
  answer: string;
};
